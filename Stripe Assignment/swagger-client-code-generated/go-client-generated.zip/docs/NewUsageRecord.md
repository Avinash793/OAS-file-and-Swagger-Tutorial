# NewUsageRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Quantity** | **int32** | The usage quantity for the specified timestamp. | [default to null]
**SubscriptionItem** | **string** | The ID of the subscription item this usage record contains data for. | [default to null]
**Timestamp** | **int32** | The timestamp for the usage event. This timestamp must be within the current billing period of the subscription of the provided &#x60;subscription_item&#x60;. | [default to null]
**Action** | **int32** | Valid values are &#x60;increment&#x60; (default) or &#x60;set&#x60;. When using &#x60;increment&#x60; the specified &#x60;quantity&#x60; will be added to the usage at the specified timestamp. The &#x60;set&#x60; action will overwrite the usage quantity at that timestamp. If the subscription has [billing thresholds](https://stripe.com/docs/api/subscriptions/object#subscription_object-billing_thresholds), &#x60;increment&#x60; is the only allowed value. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


