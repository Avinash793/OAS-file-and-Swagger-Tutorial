# \DefaultApi

All URIs are relative to *https://api.stripe.com/v1*

Method | HTTP request | Description
------------- | ------------- | -------------
[**SubscriptionItemsSubscriptionItemUsageRecordSummariesGet**](DefaultApi.md#SubscriptionItemsSubscriptionItemUsageRecordSummariesGet) | **Get** /subscription_items/{subscription_item}/usage_record_summaries | 
[**SubscriptionItemsSubscriptionItemUsageRecordsPost**](DefaultApi.md#SubscriptionItemsSubscriptionItemUsageRecordsPost) | **Post** /subscription_items/{subscription_item}/usage_records | 


# **SubscriptionItemsSubscriptionItemUsageRecordSummariesGet**
> UsageRecordSummary SubscriptionItemsSubscriptionItemUsageRecordSummariesGet(ctx, subscriptionItem, optional)


For the specified subscription item, returns a list of summary objects. Each object in the list provides usage information thatâ€™s been summarized from multiple usage records and over a subscription billing period (e.g., 15 usage records in the billing planâ€™s month of September).  The list is sorted in reverse-chronological order (newest first). The first list item represents the most current usage period that hasnâ€™t ended yet. Since new usage records can still be added, the returned summary information for the subscription itemâ€™s ID should be seen as unstable until the subscription billing period ends. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **subscriptionItem** | **string**| Only summary items for the given subscription item. | 
 **optional** | ***SubscriptionItemsSubscriptionItemUsageRecordSummariesGetOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a SubscriptionItemsSubscriptionItemUsageRecordSummariesGetOpts struct

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------

 **endingBefore** | **optional.String**| A cursor for use in pagination. &#x60;ending_before&#x60; is an object ID that defines your place in the list. For instance, if you make a list request and receive 100 objects, starting with &#x60;obj_bar&#x60;, your subsequent call can include &#x60;ending_before&#x3D;obj_bar&#x60; in order to fetch the previous page of the list. | 
 **limit** | **optional.Int32**| A limit on the number of objects to be returned. Limit can range between 1 and 100, and the default is 10. | 
 **startingAfter** | **optional.String**| A cursor for use in pagination. &#x60;starting_after&#x60; is an object ID that defines your place in the list. For instance, if you make a list request and receive 100 objects, ending with &#x60;obj_foo&#x60;, your subsequent call can include &#x60;starting_after&#x3D;obj_foo&#x60; in order to fetch the next page of the list | 

### Return type

[**UsageRecordSummary**](usageRecordSummary.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **SubscriptionItemsSubscriptionItemUsageRecordsPost**
> UsageRecord SubscriptionItemsSubscriptionItemUsageRecordsPost(ctx, subscriptionItem, newUsageRecord)


Creates a usage record for a specified subscription item and date, and fills it with a quantity.  Usage records provide `quantity` information that Stripe uses to track how much a customer is using your service. With usage information and the pricing model set up by the [metered billing](https://stripe.com/docs/billing/subscriptions/metered-billing) plan, Stripe helps you send accurate invoices to your customers.  The default calculation for usage is to add up all the `quantity` values of the usage records within a billing period. You can change this default behavior with the billing planâ€™s `aggregate_usage` [parameter](https://stripe.com/docs/api/plans/create#create_plan-aggregate_usage). When there is more than one usage record with the same timestamp, Stripe adds the quantity values together. In most cases, this is the desired resolution, however, you can change this behavior with the `action` parameter.  The default pricing model for metered billing is [per-unit](https://stripe.com/docs/api/plans/object#plan_object-billing_scheme) pricing. For finer granularity, you can configure metered billing to have a [tiered](https://stripe.com/docs/billing/subscriptions/tiers) pricing model. 

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **subscriptionItem** | **string**| The ID of the subscription item for this usage record. | 
  **newUsageRecord** | [**NewUsageRecord**](NewUsageRecord.md)| New usage record | 

### Return type

[**UsageRecord**](usageRecord.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

