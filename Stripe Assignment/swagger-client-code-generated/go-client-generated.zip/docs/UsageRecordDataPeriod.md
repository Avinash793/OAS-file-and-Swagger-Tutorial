# UsageRecordDataPeriod

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**End** | **int32** | Ending timestamp. | [optional] [default to null]
**Start** | **int32** | Starting timestamp. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


