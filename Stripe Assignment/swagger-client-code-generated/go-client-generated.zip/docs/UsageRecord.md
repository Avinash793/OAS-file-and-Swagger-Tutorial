# UsageRecord

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | Unique identifier for the object. | [optional] [default to null]
**Object** | **string** | String representing the objectâ€™s type. Objects of the same type share the same value. | [optional] [default to null]
**Livemode** | **bool** | Has the value &#x60;true&#x60; if the object exists in live mode or the value &#x60;false&#x60; if the object exists in test mode. | [optional] [default to null]
**Quantity** | **int32** | The usage quantity for the specified date. | [optional] [default to null]
**SubscriptionItem** | **string** | The ID of the subscription item this usage record contains data for. | [optional] [default to null]
**Timestamp** | **int32** | The timestamp when this usage occurred. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


