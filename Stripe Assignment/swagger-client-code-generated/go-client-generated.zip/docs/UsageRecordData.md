# UsageRecordData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **string** | ID of the usage record. | [optional] [default to null]
**Object** | **string** | String representing the objectâ€™s type. Objects of the same type share the same value. | [optional] [default to null]
**Invoice** | **string** | ID of the invoice. | [optional] [default to null]
**Livemode** | **bool** | Has the value &#x60;true&#x60; if the object exists in live mode or the value &#x60;false&#x60; if the object exists in test mode. | [optional] [default to null]
**Period** | [***UsageRecordDataPeriod**](usageRecordData_period.md) |  | [optional] [default to null]
**SubscriptionItem** | **string** | ID of the subscription item. | [optional] [default to null]
**TotalUsage** | **int32** | The total number of usage records in the billing plan. | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


