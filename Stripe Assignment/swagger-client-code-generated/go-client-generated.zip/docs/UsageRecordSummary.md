# UsageRecordSummary

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Object** | **string** | String representing the objectâ€™s type. Objects of the same type share the same value. | [optional] [default to null]
**Url** | **string** | URL of the subscription item summaries. | [optional] [default to null]
**HasMore** | **bool** | Whether or not there are more elements available after this set. If &#x60;false&#x60;, this set comprises the end of the list. | [optional] [default to null]
**Data** | [**[]UsageRecordData**](usageRecordData.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


