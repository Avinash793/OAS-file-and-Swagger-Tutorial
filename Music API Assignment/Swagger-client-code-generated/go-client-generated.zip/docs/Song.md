# Song

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Id** | **int32** | Song ID | [optional] [default to null]
**Title** | **string** | Song title | [optional] [default to null]
**Artist** | **string** | Song artist | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


