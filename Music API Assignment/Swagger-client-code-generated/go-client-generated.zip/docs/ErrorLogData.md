# ErrorLogData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Entry** | **int32** | Log entry number | [optional] [default to null]
**Date** | **string** | Log entry date | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


