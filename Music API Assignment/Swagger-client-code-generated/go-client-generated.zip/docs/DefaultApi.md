# \DefaultApi

All URIs are relative to *https://api.muzicplayz.com/v3*

Method | HTTP request | Description
------------- | ------------- | -------------
[**CreatePlaylist**](DefaultApi.md#CreatePlaylist) | **Post** /playlist | 
[**DeletePlaylist**](DefaultApi.md#DeletePlaylist) | **Delete** /playlist/{playlist-id} | 
[**GetImage**](DefaultApi.md#GetImage) | **Get** /playlist/{playlist-id}/image | 
[**GetPlaylists**](DefaultApi.md#GetPlaylists) | **Get** /playlist | 
[**ReturnPlaylists**](DefaultApi.md#ReturnPlaylists) | **Get** /playlist/{playlist-id} | 


# **CreatePlaylist**
> CreatePlaylist(ctx, newPlaylist)


### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **newPlaylist** | [**NewPlaylist**](NewPlaylist.md)| New playlist | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **DeletePlaylist**
> DeletePlaylist(ctx, playlistId)


Deletes a playlist.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **playlistId** | **string**| ID of the playlist to delete | 

### Return type

 (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetImage**
> *os.File GetImage(ctx, playlistId)


Returns a generated image for the playlist.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **playlistId** | **string**| ID of the playlist to generate the image for | 

### Return type

[***os.File**](*os.File.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: image/png

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **GetPlaylists**
> GetPlaylists(ctx, optional)


Returns one or more playlists.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
 **optional** | ***GetPlaylistsOpts** | optional parameters | nil if no parameters

### Optional Parameters
Optional parameters are passed through a pointer to a GetPlaylistsOpts struct

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **optional.Int32**| Number of playlists to return | 
 **offset** | **optional.Int32**| Number of playlists to skip | 
 **search** | **optional.String**| Search term | 

### Return type

 (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **ReturnPlaylists**
> PlaylistWithSongs ReturnPlaylists(ctx, playlistId)


Returns a playlist.

### Required Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **ctx** | **context.Context** | context for authentication, logging, cancellation, deadlines, tracing, etc.
  **playlistId** | **string**| ID of the playlist to return | 

### Return type

[**PlaylistWithSongs**](playlistWithSongs.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

