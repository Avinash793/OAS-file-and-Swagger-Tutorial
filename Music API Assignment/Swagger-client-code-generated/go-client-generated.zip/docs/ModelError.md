# ModelError

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorMessage** | **string** | Human readable error message | [optional] [default to null]
**LogData** | [***ErrorLogData**](error_logData.md) |  | [optional] [default to null]

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


