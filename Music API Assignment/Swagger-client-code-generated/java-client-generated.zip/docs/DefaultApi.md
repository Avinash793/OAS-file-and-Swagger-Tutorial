# DefaultApi

All URIs are relative to *https://api.muzicplayz.com/v3*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPlaylist**](DefaultApi.md#createPlaylist) | **POST** /playlist | 
[**deletePlaylist**](DefaultApi.md#deletePlaylist) | **DELETE** /playlist/{playlist-id} | 
[**getImage**](DefaultApi.md#getImage) | **GET** /playlist/{playlist-id}/image | 
[**getPlaylists**](DefaultApi.md#getPlaylists) | **GET** /playlist | 
[**returnPlaylists**](DefaultApi.md#returnPlaylists) | **GET** /playlist/{playlist-id} | 


<a name="createPlaylist"></a>
# **createPlaylist**
> createPlaylist(newPlaylist)



### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
NewPlaylist newPlaylist = new NewPlaylist(); // NewPlaylist | New playlist
try {
    apiInstance.createPlaylist(newPlaylist);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#createPlaylist");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **newPlaylist** | [**NewPlaylist**](NewPlaylist.md)| New playlist |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deletePlaylist"></a>
# **deletePlaylist**
> deletePlaylist(playlistId)



Deletes a playlist.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String playlistId = "playlistId_example"; // String | ID of the playlist to delete
try {
    apiInstance.deletePlaylist(playlistId);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#deletePlaylist");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **playlistId** | **String**| ID of the playlist to delete |

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getImage"></a>
# **getImage**
> File getImage(playlistId)



Returns a generated image for the playlist.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String playlistId = "playlistId_example"; // String | ID of the playlist to generate the image for
try {
    File result = apiInstance.getImage(playlistId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#getImage");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **playlistId** | **String**| ID of the playlist to generate the image for |

### Return type

[**File**](File.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: image/png

<a name="getPlaylists"></a>
# **getPlaylists**
> getPlaylists(limit, offset, search)



Returns one or more playlists.

### Example
```java
// Import classes:
//import io.swagger.client.ApiClient;
//import io.swagger.client.ApiException;
//import io.swagger.client.Configuration;
//import io.swagger.client.auth.*;
//import io.swagger.client.api.DefaultApi;

ApiClient defaultClient = Configuration.getDefaultApiClient();

// Configure HTTP basic authorization: basicAuth
HttpBasicAuth basicAuth = (HttpBasicAuth) defaultClient.getAuthentication("basicAuth");
basicAuth.setUsername("YOUR USERNAME");
basicAuth.setPassword("YOUR PASSWORD");

DefaultApi apiInstance = new DefaultApi();
Integer limit = 56; // Integer | Number of playlists to return
Integer offset = 56; // Integer | Number of playlists to skip
String search = "search_example"; // String | Search term
try {
    apiInstance.getPlaylists(limit, offset, search);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#getPlaylists");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **Integer**| Number of playlists to return | [optional]
 **offset** | **Integer**| Number of playlists to skip | [optional]
 **search** | **String**| Search term | [optional]

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="returnPlaylists"></a>
# **returnPlaylists**
> PlaylistWithSongs returnPlaylists(playlistId)



Returns a playlist.

### Example
```java
// Import classes:
//import io.swagger.client.ApiException;
//import io.swagger.client.api.DefaultApi;


DefaultApi apiInstance = new DefaultApi();
String playlistId = "playlistId_example"; // String | ID of the playlist to return
try {
    PlaylistWithSongs result = apiInstance.returnPlaylists(playlistId);
    System.out.println(result);
} catch (ApiException e) {
    System.err.println("Exception when calling DefaultApi#returnPlaylists");
    e.printStackTrace();
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **playlistId** | **String**| ID of the playlist to return |

### Return type

[**PlaylistWithSongs**](PlaylistWithSongs.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

