
# Song

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | Song ID |  [optional]
**title** | **String** | Song title |  [optional]
**artist** | **String** | Song artist |  [optional]



