
# ErrorLogData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entry** | **Integer** | Log entry number |  [optional]
**date** | **String** | Log entry date |  [optional]



