
# PlaylistWithSongs

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **Integer** | ID of the playlist |  [optional]
**name** | **String** | Name of the playlist |  [optional]
**song** | [**List&lt;Song&gt;**](Song.md) | Song in the playlist |  [optional]



