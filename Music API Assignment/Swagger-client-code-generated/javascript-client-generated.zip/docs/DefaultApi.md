# MusicApi.DefaultApi

All URIs are relative to *https://api.muzicplayz.com/v3*

Method | HTTP request | Description
------------- | ------------- | -------------
[**createPlaylist**](DefaultApi.md#createPlaylist) | **POST** /playlist | 
[**deletePlaylist**](DefaultApi.md#deletePlaylist) | **DELETE** /playlist/{playlist-id} | 
[**getImage**](DefaultApi.md#getImage) | **GET** /playlist/{playlist-id}/image | 
[**getPlaylists**](DefaultApi.md#getPlaylists) | **GET** /playlist | 
[**returnPlaylists**](DefaultApi.md#returnPlaylists) | **GET** /playlist/{playlist-id} | 


<a name="createPlaylist"></a>
# **createPlaylist**
> createPlaylist(newPlaylist)



### Example
```javascript
var MusicApi = require('music_api');

var apiInstance = new MusicApi.DefaultApi();

var newPlaylist = new MusicApi.NewPlaylist(); // NewPlaylist | New playlist


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.createPlaylist(newPlaylist, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **newPlaylist** | [**NewPlaylist**](NewPlaylist.md)| New playlist | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="deletePlaylist"></a>
# **deletePlaylist**
> deletePlaylist(playlistId)



Deletes a playlist.

### Example
```javascript
var MusicApi = require('music_api');

var apiInstance = new MusicApi.DefaultApi();

var playlistId = "playlistId_example"; // String | ID of the playlist to delete


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.deletePlaylist(playlistId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **playlistId** | **String**| ID of the playlist to delete | 

### Return type

null (empty response body)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="getImage"></a>
# **getImage**
> File getImage(playlistId)



Returns a generated image for the playlist.

### Example
```javascript
var MusicApi = require('music_api');

var apiInstance = new MusicApi.DefaultApi();

var playlistId = "playlistId_example"; // String | ID of the playlist to generate the image for


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.getImage(playlistId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **playlistId** | **String**| ID of the playlist to generate the image for | 

### Return type

**File**

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: image/png

<a name="getPlaylists"></a>
# **getPlaylists**
> getPlaylists(opts)



Returns one or more playlists.

### Example
```javascript
var MusicApi = require('music_api');
var defaultClient = MusicApi.ApiClient.instance;

// Configure HTTP basic authorization: basicAuth
var basicAuth = defaultClient.authentications['basicAuth'];
basicAuth.username = 'YOUR USERNAME';
basicAuth.password = 'YOUR PASSWORD';

var apiInstance = new MusicApi.DefaultApi();

var opts = { 
  'limit': 56, // Number | Number of playlists to return
  'offset': 56, // Number | Number of playlists to skip
  'search': "search_example" // String | Search term
};

var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully.');
  }
};
apiInstance.getPlaylists(opts, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **limit** | **Number**| Number of playlists to return | [optional] 
 **offset** | **Number**| Number of playlists to skip | [optional] 
 **search** | **String**| Search term | [optional] 

### Return type

null (empty response body)

### Authorization

[basicAuth](../README.md#basicAuth)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

<a name="returnPlaylists"></a>
# **returnPlaylists**
> PlaylistWithSongs returnPlaylists(playlistId)



Returns a playlist.

### Example
```javascript
var MusicApi = require('music_api');

var apiInstance = new MusicApi.DefaultApi();

var playlistId = "playlistId_example"; // String | ID of the playlist to return


var callback = function(error, data, response) {
  if (error) {
    console.error(error);
  } else {
    console.log('API called successfully. Returned data: ' + data);
  }
};
apiInstance.returnPlaylists(playlistId, callback);
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **playlistId** | **String**| ID of the playlist to return | 

### Return type

[**PlaylistWithSongs**](PlaylistWithSongs.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/json

