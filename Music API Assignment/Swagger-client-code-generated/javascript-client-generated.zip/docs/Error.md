# MusicApi.Error

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**errorMessage** | **String** | Human readable error message | [optional] 
**logData** | [**ErrorLogData**](ErrorLogData.md) |  | [optional] 


