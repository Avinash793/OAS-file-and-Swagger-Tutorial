# MusicApi.ErrorLogData

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**entry** | **Number** | Log entry number | [optional] 
**_date** | **String** | Log entry date | [optional] 


